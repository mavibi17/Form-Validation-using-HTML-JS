function validate(event) 
{
    event.preventDefault();

    document.getElementById("errorname").innerText = "";
    document.getElementById("errorphn").innerText = "";
    document.getElementById("erroremail").innerText = "";
    document.getElementById("errorpass").innerText = "";

    let name = document.getElementById("name").value.trim();
    if(name === "") 
        {
        document.getElementById("errorname").innerText="Name cannot be empty";
        return;
    }

    let phn=document.getElementsByClassName("phn")[0].value.trim();
    let phonePattern=/^\d{10}$/;
    if (!phonePattern.test(phn)) {
        document.getElementById("errorphn").innerText="Invalid phone number";
        return;
    }

    let email=document.getElementById("email").value.trim();
    let emailPattern=/^[^@]+@gmail\.com$/
    if (!emailPattern.test(email)) 
        {
        document.getElementById("erroremail").innerText="Invalid email address (lowercase only)";
        return;
    }

    let pass=document.getElementById("pass").value.trim();
    if (pass.length!==6) 
        {
        document.getElementById("errorpass").innerText="Password must be exactly 6 characters";
        return;
    }
    alert("Form submitted successfully");
}
